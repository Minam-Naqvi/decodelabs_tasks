# DecodeLabs Project 2 — Exploratory Data Analysis (EDA)

**Intern:** Syeda Minam Zehra  
**Batch:** 2026

## Project objective
Explore the supplied order dataset to understand distributions, trends, potential outliers and key patterns, as required by the DecodeLabs Project 2 brief.

## Repository structure
```text
.
├── Project_2_EDA.ipynb
├── README.md
├── requirements.txt
├── data/
│   ├── Dataset for Data Analytics.xlsx
│   └── cleaned_orders.csv
└── visualizations/
    ├── monthly_orders.png
    ├── revenue_by_product.png
    ├── order_status.png
    └── total_price_distribution.png
```

## Run the project
1. Install Python 3.9+.
2. Install dependencies: `pip install -r requirements.txt`
3. Open `Project_2_EDA.ipynb` in Jupyter Notebook, JupyterLab or Google Colab.
4. Run all cells from top to bottom.

## Analysis performed
- Dataset dimensions, data types, missing values and duplicate checks.
- Count, mean, median, minimum, maximum and standard deviation.
- Product, order status, payment method, referral source and coupon distributions.
- Monthly order and revenue trends.
- Product-level order and revenue summaries.
- IQR-based potential outlier detection on `TotalPrice`.
- Correlation analysis for numeric variables.

## Data handling notes
- The original workbook is retained in `data/` for reproducibility.
- Missing `CouponCode` values are labelled `No Coupon`; rows are not dropped.
- No duplicate rows or duplicate OrderIDs were found in the supplied file.
- The dataset covers 1 January 2023 to 30 June 2025. 2025 is a partial year, so annual comparisons should account for this.
- Outliers are statistical flags for review, not necessarily data errors.

## Important
This project is an exploratory analysis of the supplied training dataset. Interpretations are descriptive and do not establish causation.
