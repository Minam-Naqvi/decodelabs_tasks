# DecodeLabs Project 3 - SQL Data Analysis Package

This repository zip file contains all code files, dataset, and SQL queries required for DecodeLabs Project 3 submission.

## File Inventory:
1. `sales_dataset.xlsx` - Primary Excel dataset containing 1,200 order records.
2. `sales_dataset.csv` - Cleaned CSV data format.
3. `sql_queries.sql` - Complete SQL scripts (Table DDL, aggregation queries, HAVING clauses, filtering).
4. `data_analysis.py` - Python data processing script.
5. `Data Analytics Project 3.pdf` - Project Industrial Training Kit Guide.

## Key Project Features:
- Complete SQL query execution sequence (`FROM` -> `WHERE` -> `GROUP BY` -> `HAVING` -> `SELECT` -> `ORDER BY`).
- Aggregations (`COUNT`, `SUM`, `AVG`) and NULL value tracking.
- Product performance and order status breakdown.
