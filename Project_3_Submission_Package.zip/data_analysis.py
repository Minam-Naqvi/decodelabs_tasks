# DecodeLabs Project 3: Data Analysis & Visualization Script

import pandas as pd

# Load Dataset
df = pd.read_excel('sales_dataset.xlsx')

# Data Summary
print("--- Dataset Overview ---")
print(df.info())

# Summary Statistics
print("\n--- Metric Summary ---")
print(df[['Quantity', 'UnitPrice', 'TotalPrice']].describe())

# Key Aggregations
product_summary = df.groupby('Product').agg(
    Total_Orders=('OrderID', 'count'),
    Total_Quantity=('Quantity', 'sum'),
    Total_Revenue=('TotalPrice', 'sum')
).reset_index().sort_values(by='Total_Revenue', ascending=False)

print("\n--- Revenue by Product ---")
print(product_summary)
