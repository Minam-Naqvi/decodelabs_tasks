-- DecodeLabs Project 3: SQL Data Analysis Scripts
-- Dataset: Sales Data Analytics

-- Table Creation Schema
CREATE TABLE sales_data (
    OrderID VARCHAR(20) PRIMARY KEY,
    Date DATE,
    CustomerID VARCHAR(20),
    Product VARCHAR(50),
    Quantity INT,
    UnitPrice DECIMAL(10, 2),
    ShippingAddress VARCHAR(100),
    PaymentMethod VARCHAR(50),
    OrderStatus VARCHAR(50),
    TrackingNumber VARCHAR(50),
    ItemsInCart INT,
    CouponCode VARCHAR(50),
    ReferralSource VARCHAR(50),
    TotalPrice DECIMAL(10, 2)
);

-- Query 1: Total Revenue and Orders by Product
SELECT 
    Product, 
    COUNT(OrderID) AS TotalOrders, 
    SUM(Quantity) AS TotalUnitsSold, 
    SUM(TotalPrice) AS TotalRevenue
FROM sales_data
GROUP BY Product
ORDER BY TotalRevenue DESC;

-- Query 2: High Value Orders Filter
SELECT 
    OrderID, CustomerID, Product, TotalPrice, PaymentMethod
FROM sales_data
WHERE TotalPrice > 2000 AND OrderStatus = 'Delivered';

-- Query 3: Order Status Breakdown
SELECT 
    OrderStatus, 
    COUNT(*) AS TotalCount,
    ROUND(AVG(TotalPrice), 2) AS AverageOrderValue
FROM sales_data
GROUP BY OrderStatus
ORDER BY TotalCount DESC;

-- Query 4: Coupon Code Usage & Discount Evaluation
SELECT 
    COALESCE(CouponCode, 'No Coupon') AS CouponUsed,
    COUNT(*) AS OrderCount,
    SUM(TotalPrice) AS Revenue
FROM sales_data
GROUP BY CouponCode;
